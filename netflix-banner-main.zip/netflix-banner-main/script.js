
// Seleciona o botão com o ID 'cta-button'
const ctaButton = document.getElementById('cta-button');

// Adiciona um evento de clique ao botão
ctaButton.addEventListener('click', function() {
    alert('Você será um super programador!');
});
